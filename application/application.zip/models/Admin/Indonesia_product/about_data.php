<?php
class indonesia_product_data {

	public $id;
	public $title;
	public $thumbnail;
	public $file;
	public $post_date;
	public $status;


	public function __construct($arr) {
		foreach(get_object_vars($this) as $key => $val) {
			switch($key) {
				case 'thumbnail':
					if(array_key_exists('thumbnail', $arr) AND $arr['thumbnail'] !== NULL) {
						$CI =& get_instance();
						$this->$key = $CI->config->item('website_assets').'about/'.$arr['about_header'];
					}
					break;
				default:
					if(array_key_exists($key, $arr))
						$this->$key = $arr[$key];
					break;
			}
		}
	}

	public function to_array() { return (array) $this; }
}
