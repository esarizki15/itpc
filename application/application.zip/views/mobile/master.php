<!DOCTYPE html>
<html dir="ltr" lang="en-US">
	<head>
		<?php
			echo $main_css;
		?>
	</head>
	<body>
			<?php echo $content; ?>
	</body>

</html>
