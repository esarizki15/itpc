<!-- Navigation Menu-->
<ul class="navigation-menu">
      <li class="has-submenu">
          <a href="<?php echo base_url();?>Admin"><i class="dripicons-home"></i> Dashborad</a>
      </li>
      <li class="has-submenu">
          <a href="#"><i class="dripicons-suitcase"></i> Exporter<i class="mdi mdi-chevron-down mdi-drop"></i></a>
          <ul class="submenu megamenu">
              <li>
                  <ul>
                      <li><a href="<?php echo base_url()?>Admin/Expoter_management">Managamnet</a></li>
                      <li><a href="<?php echo base_url()?>Admin/expirate_list">Categories</a></li>
                      <li><a href="<?php echo base_url()?>Admin/Exporter_subcategory">Sub Categories</a></li>
                  </ul>
              </li>
          </ul>
      </li>
      <li class="has-submenu">
          <a href="<?php echo base_url();?>Admin"><i class="dripicons-home"></i> Importer</a>
      </li>
      <li class="has-submenu">
          <a href="#"><i class="dripicons-suitcase"></i> News & Exhibitions<i class="mdi mdi-chevron-down mdi-drop"></i></a>
          <ul class="submenu megamenu">
              <li>
                  <ul>
                      <li><a href="<?php echo base_url()?>Admin">News Managamnet</a></li>
                      <li><a href="<?php echo base_url()?>Admin">Exhibitions Managamnet</a></li>

                  </ul>
              </li>
          </ul>
      </li>



      <li class="has-submenu">
          <a href="#"><i class="dripicons-suitcase"></i> Other Fiture<i class="mdi mdi-chevron-down mdi-drop"></i></a>
          <ul class="submenu megamenu">
              <li>
                  <ul>
                      <li><a href="ui-alerts.html">About Us</a></li>
                      <li><a href="ui-alerts.html">Contact Us</a></li>
                      <li><a href="ui-alerts.html">Indonesia Product</a></li>
                      <li><a href="ui-alerts.html">Useful links</a></li>
                  </ul>
              </li>
          </ul>
      </li>


</ul>
  <!-- End navigation menu -->
