<!-- Navigation Menu-->
<ul class="navigation-menu">
      <li class="has-submenu">
          <a href="<?php echo base_url();?>Admin"><i class="dripicons-home"></i> Dashborad</a>
      </li>
      <li class="has-submenu">
          <a href="#"><i class="dripicons-suitcase"></i> Exporter<i class="mdi mdi-chevron-down mdi-drop"></i></a>
          <ul class="submenu megamenu">
              <li>
                  <ul>
                      <li><a href="<?php echo base_url()?>Admin/Expoter_management">Managamnet</a></li>
                      <li><a href="<?php echo base_url()?>Admin/expirate_list">Categories</a></li>
                      <li><a href="<?php echo base_url()?>Admin/Exporter_subcategory">Sub Categories</a></li>
                  </ul>
              </li>
          </ul>
      </li>
      <li class="has-submenu">
          <a href="<?php echo base_url();?>Admin/Inquiry_management"><i class="dripicons-document"></i>Inquiry</a>
      </li>
      <li class="has-submenu">
          <a href="<?php echo base_url();?>Admin"><i class="dripicons-user"></i> Importer</a>
      </li>
      <li class="has-submenu">
          <a href="#"><i class="dripicons-suitcase"></i> News & Exhibitions<i class="mdi mdi-chevron-down mdi-drop"></i></a>
          <ul class="submenu megamenu">
              <li>
                  <ul>
                      <li><a href="<?php echo base_url()?>Admin/News_management">Managamnet</a></li>
                      <li><a href="<?php echo base_url()?>Admin/News_categories">Categories</a></li>
                  </ul>
              </li>
          </ul>
      </li>



      <li class="has-submenu">
          <a href="#"><i class="dripicons-suitcase"></i> Other Fiture<i class="mdi mdi-chevron-down mdi-drop"></i></a>
          <ul class="submenu megamenu">
              <li>
                  <ul>
                      <li><a href="<?php echo base_url()?>Admin/` About_managment">About Us</a></li>
                      <li><a href="<?php echo base_url()?>Admin/Contact_managment">Contact Us</a></li>
                      <li><a href="<?php echo base_url()?>Admin/Indonesia_product_managment">Indonesia Product</a></li>
                      <li><a href="<?php echo base_url()?>Admin/Useful_link_managment">Useful links</a></li>
                  </ul>
              </li>
          </ul>
      </li>


</ul>
  <!-- End navigation menu -->
