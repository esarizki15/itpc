<!-- DataTables -->
<link href="<?php echo $this->config->item('admin_source'); ?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('admin_source'); ?>plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- Responsive datatable examples -->
<link href="<?php echo $this->config->item('admin_source'); ?>plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css">

<!-- link href="<?php echo $this->config->item('admin_source'); ?>plugins/data-tabel/css/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('admin_source'); ?>plugins/data-tabel/css/jquery.dataTables.css" rel="stylesheet" type="text/css" -->
