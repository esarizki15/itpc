<?php 
    $lang['language']['home']='HOGAR';
    $lang['language']['aboutus']='SOBRE NOSOTRAS';
    $lang['language']['trade']='COMERCIO';
    $lang['language']['news']='NOTICIAS';
    $lang['language']['contactus']='CONTÁCTENOS';
    $lang['language']['login']='ACCESO';
    $lang['language']['logout']='LOGOUT';
    $lang['language']['exporter_dashboard']='CUENTA';
?>