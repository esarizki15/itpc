<?php 
    $lang['language']['home']='HOME';
    $lang['language']['aboutus']='ABOUT US';
    $lang['language']['trade']='TRADE WITH INDONESIA';
    $lang['language']['news']='NEWS & EXHIBITIONS';
    $lang['language']['contactus']='CONTACT US';
    $lang['language']['login']='LOGIN';
    $lang['language']['logout']='LOGOUT';
    $lang['language']['exporter_dashboard']='ACCOUNT';
    
?>