<?php 
    $lang['language']['home']='BERANDA';
    $lang['language']['aboutus']='TENTANG KAMI ';
    $lang['language']['trade']='PERNIAGAAN';
    $lang['language']['news']='BERITA';
    $lang['language']['contactus']='HUBUNGI KAMI';
    $lang['language']['login']='MASUK';
    $lang['language']['logout']='LOGOUT';
    $lang['language']['exporter_dashboard']='AKUN';
?>