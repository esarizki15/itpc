<?php
/*$config = [
	'useragent' => 'zambert system',
	'protocol' => 'smtp',
	'mailtype'  => 'html',
	'charset'   => 'utf-8',
	'smtp_host' => 'smtp.gmail.com',
	'smtp_user' => 'zamberttest2020batch2@gmail.com',  // Email gmail
	'smtp_pass'   => '2020zambert',  // Password gmail
	'smtp_crypto' => 'ssl',
	'smtp_port'   => 465,
	'crlf'    => "\r\n",
	'newline' => "\r\n"
];*/

/*
$config= [
	'useragent' => 'zambert system',
	'protocol' => 'smtp',
	'mailtype'  => 'html',
	'charset'   => 'utf-8',
	'smtp_host' => 'smtp.gmail.com',
	'smtp_user' => 'zamberttest2020batch2@gmail.com',  // Email gmail
	'smtp_pass'   => '2020zambert',  // Password gmail
	'smtp_crypto' => 'tls',
	'smtp_port'   => 587,
	'crlf'    => "\r\n",
	'newline' => "\r\n"
];*/


$config = [
	'useragent' => 'ITPC system',
	'protocol' => 'smtp',
	'mailtype'  => 'html',
	'charset'   => 'utf-8',
	'smtp_host' => 'smtp.gmail.com',
	'smtp_user' => 'itpcmaster2020@gmail.com',  // Email gmail
	'smtp_pass'   => 'itpc2020',  // Password gmail
	'smtp_crypto' => 'tls',
	'smtp_port'   => 587,
	'crlf'    => "\r\n",
	'newline' => "\r\n"
];
