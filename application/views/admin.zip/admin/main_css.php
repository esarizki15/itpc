<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<title>ITPC Admimistrator</title>
<meta content="Admin Dashboard" name="description" />
<meta content="ThemeDesign" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<!-- App Icons -->
<link rel="shortcut icon" href="assets/images/favicon.ico">

<!-- App css -->
<link href="<?php echo $this->config->item('admin_source'); ?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('admin_source'); ?>css/icons.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('admin_source'); ?>css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('admin_source'); ?>plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
