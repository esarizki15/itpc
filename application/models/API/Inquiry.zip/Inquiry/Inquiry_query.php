<?php
class Inquiry_query extends CI_Model{

  public function Submit_inquiry($inquiry_data){
  //$result = $this->db->insert('zambert_user',$user);
  $result =	$this->db->insert_batch('itpc_inquiry',$inquiry_data);
  $insert_id = $this->db->insert_id();
  $this->db->trans_start();
  $this->db->trans_complete();
  if(!$result)
     $this->session->set_flashdata('error', 'Gagal menyimpan data');
  return $insert_id;
  }

  public function Submit_notif_inquiry($notif){
  //$result = $this->db->insert('zambert_user',$user);
  $result =	$this->db->insert_batch('itpc_notif_inquiry',$notif);
  if(!$result)
     $this->session->set_flashdata('error', 'Gagal menyimpan data');
  return $result;
  }

}
